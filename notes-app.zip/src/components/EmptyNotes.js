import React from 'react'

export default function EmptyNotes() {
  return (
    <div>
    <h3>Notes not found</h3>
  </div>
  )
}
