export default function NotesWrapper({children}) {
  return (
    <div className="notes-wrapper">{children}</div>
  )
}