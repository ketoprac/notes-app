import React from 'react'

export default function Footer() {
  return (
    <footer>Proudly made by Hafiedz Mada</footer>
  )
}
