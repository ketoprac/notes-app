import React, { useState } from "react";
import { InputNote } from "./components/InputNote";
import { NoteItem } from "./components/NoteItem";
import { Navbar } from "./components/Navbar";
import { getInitialData, showFormattedDate } from "./utils/index";
import Wrapper from "./components/Wrapper";
import NotesWrapper from "./components/NotesWrapper";
import Footer from "./components/Footer";
import EmptyNotes from "./components/EmptyNotes";

export default function NotesApp() {
  const [notes, setNotes] = useState(getInitialData());
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [keyword, setKeyword] = useState("");
  const [titleCount, setTitleCount] = useState(0);

  const onTitleChange = (e) => {
    setTitle(e.target.value);
    setTitleCount(e.target.value.length);
  };

  const onBodyChange = (e) => {
    setBody(e.target.value);
  };

  const onSearchChange = (e) => {
    setKeyword(e.target.value);
  };

  const note = {
    id: +new Date(),
    title,
    body,
    archived: false,
    createdAt: +new Date(),
  };

  const submitHandler = (e) => {
    e.preventDefault();
    if (title === "" || body === "") {
      return alert("Please enter the title and the body");
    }
    const newNotes = [...notes, note];
    setNotes(newNotes);
    setTitle("");
    setBody("");
    setTitleCount(0);
  };

  const deleteHandler = (id) => {
    let result = window.confirm("Are you sure want to delete this note?");
    if(result) {
      setNotes((notes) => notes.filter((note) => note.id !== id));
    } else {
      return null;
    }
  };

  const archiveHandler = (id) => {
    setNotes((notes) =>
      notes.map((note) => {
        if (note.id === id && note.archived === false) {
          return { ...note, archived: true };
        } else if (note.id === id && note.archived === true) {
          return { ...note, archived: false };
        }
        return note;
      })
    );
  };

  const checkNotes = () => {
    if (notes.length === 0) {
      return false;
    } else {
      return true;
    }
  };

  return (
    <>
      <Navbar onSearchChange={onSearchChange} keyword={keyword} />
      <Wrapper>
        <h2>Add Notes</h2>
        <InputNote
          onSubmit={submitHandler}
          onTitleChange={onTitleChange}
          onBodyChange={onBodyChange}
          titleCount={titleCount}
          title={title}
          body={body}
        />

        <h2>Active Notes</h2>
        <NotesWrapper>
          {checkNotes() ? (
            notes
              .filter((note) => {
                if (keyword) {
                  return (note.title
                    .toLowerCase()
                    .includes(keyword.toLowerCase())) && note.archived === false;
                }
                return note.archived === false;
              })
              .map((note) => (
                <NoteItem
                  key={note.id}
                  id={note.id}
                  title={note.title}
                  body={note.body}
                  archived={note.archived}
                  createdAt={showFormattedDate(note.createdAt)}
                  onDelete={deleteHandler}
                  onArchive={archiveHandler}
                />
              ))
          ) : (
            <EmptyNotes />
          )}
        </NotesWrapper>

        <h2>Archived Notes</h2>
        <NotesWrapper>
          {checkNotes() ? (
            notes
              .filter((note) => {
                if (keyword) {
                  return (note.title
                    .toLowerCase()
                    .includes(keyword.toLowerCase())) && note.archived === true;
                }
                return note.archived === true;
              })
              .map((note) => (
                <NoteItem
                  key={note.id}
                  id={note.id}
                  title={note.title}
                  body={note.body}
                  archived={note.archived}
                  createdAt={showFormattedDate(note.createdAt)}
                  onDelete={deleteHandler}
                  onArchive={archiveHandler}
                />
              ))
          ) : (
            <EmptyNotes />
          )}
        </NotesWrapper>
      </Wrapper>
      <Footer />
    </>
  );
}
